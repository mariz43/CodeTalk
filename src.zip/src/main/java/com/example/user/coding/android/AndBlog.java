package com.example.user.coding.android;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.example.user.coding.R;

import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;


public class AndBlog extends AppCompatActivity {
    private DatabaseReference mdatabasse;

    private RecyclerView mbloglist;
    private Button pbt;

    public AndBlog() {
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_and_blog);

        mdatabasse= FirebaseDatabase.getInstance().getReference().child("Androidall").child("Blog");
        mbloglist=(RecyclerView) findViewById(R.id.aandblogl);
        pbt=(Button)findViewById(R.id.aandaddcont) ;
        mbloglist.setHasFixedSize(true);
        mbloglist.setLayoutManager(new LinearLayoutManager(this));




        pbt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(AndBlog.this,Add_andblog.class);
                startActivity(intent);
            }
        });

    }







    @Override
    protected void onStart() {
        super.onStart();
        FirebaseRecyclerAdapter<and_postitem,AndBlogviewholder> firebaseRecyclerAdapter=new FirebaseRecyclerAdapter<and_postitem, AndBlogviewholder>(
                and_postitem.class,R.layout.andblogrow,AndBlogviewholder.class,mdatabasse
        ) {



            @Override
            protected void populateViewHolder(AndBlogviewholder viewHolder, and_postitem model, int position) {

                viewHolder.settitle(model.getTitle());
                viewHolder.setdescription(model.getDescription());
                viewHolder.btncmts.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        Toast.makeText(AndBlog.this, "Comments", Toast.LENGTH_SHORT).show();
                        Intent intent=new Intent(AndBlog.this,androidview.class);
                        startActivity(intent);
                    }
                });
















            }
        };
        mbloglist.setAdapter(firebaseRecyclerAdapter);
    }


    public static class AndBlogviewholder extends RecyclerView.ViewHolder{

        View mview;Button btncmts;


        public AndBlogviewholder(View itemView) {
            super(itemView);
            mview=itemView;
            btncmts=(Button)mview.findViewById(R.id.andbutlike);
        }


        public void settitle(String title){
            TextView posttitle=(TextView) mview.findViewById(R.id.andtitleposted);
            posttitle.setText(title);


        }

        public void setdescription(String description){
            TextView postdescription=(TextView) mview.findViewById(R.id.anddescposted);
            postdescription.setText(description);


        }



    }








}

package com.example.user.coding.java;

import android.app.ProgressDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;


import com.example.user.coding.R;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

public class Addblog extends AppCompatActivity {
    private FirebaseAuth firebaseAut;
    private FirebaseAuth.AuthStateListener authStateListener;
    private DatabaseReference mdatabbase;
    private ImageButton mSelectImage;
    private EditText mPosttitle;
    private EditText mPostdesc;
    private Uri mimageUri=null;
    private Button mSubmitBtn;
    private StorageReference mstorage;
    private ProgressDialog mmprogress;
    private static final int GALLERY_REQUEST = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_addblog);



        firebaseAut=FirebaseAuth.getInstance();
        mdatabbase= FirebaseDatabase.getInstance().getReference().child("Javaall").child("Blog");
        mstorage= FirebaseStorage.getInstance().getReference();





        mPosttitle = (EditText) findViewById(R.id.posttitle);
        mPostdesc = (EditText) findViewById(R.id.postdescription);
        mSubmitBtn = (Button) findViewById(R.id.submitpost);
        mmprogress=new ProgressDialog(this);


        mSubmitBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startposting();
            }
        });
    }

    private void startposting() {mmprogress.setMessage("Posting...");

        final String titlevalue=mPosttitle.getText().toString().trim();
        final String descvalue=mPostdesc.getText().toString().trim();

        if (!TextUtils.isEmpty(titlevalue) && !TextUtils.isEmpty(descvalue)){
            mmprogress.show();


                    DatabaseReference newpost=mdatabbase.push();
                    newpost.child("title").setValue(titlevalue);
                    newpost.child("description").setValue(descvalue);
                    newpost.child("uid").setValue(firebaseAut.getCurrentUser().getUid());


                    mmprogress.dismiss();
                    startActivity(new Intent(Addblog.this,Blog.class));
                }



    }
}

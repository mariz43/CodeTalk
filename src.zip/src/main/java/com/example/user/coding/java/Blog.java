package com.example.user.coding.java;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;


import com.example.user.coding.R;
import com.example.user.coding.android.androidview;
import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class Blog extends AppCompatActivity {
    private DatabaseReference mdatabasse;

    private RecyclerView mbloglist;
    private Button pbt;



    public Blog() {
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_blog);
        mdatabasse= FirebaseDatabase.getInstance().getReference().child("Javaall").child("Blog");
        mbloglist=(RecyclerView) findViewById(R.id.blogl);
        pbt=(Button)findViewById(R.id.addcont) ;
        mbloglist.setHasFixedSize(true);
        mbloglist.setLayoutManager(new LinearLayoutManager(this));


pbt.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View view) {
      Intent intent=new Intent(Blog.this,Addblog.class);
      startActivity(intent);
    }
});



    }


    // Inflate the layout for this fragment






    @Override
    protected void onStart() {
        super.onStart();
        FirebaseRecyclerAdapter<postitem,Blogviewholder>firebaseRecyclerAdapter=new FirebaseRecyclerAdapter<postitem, Blogviewholder>(
                postitem.class, R.layout.blogrow,Blogviewholder.class,mdatabasse
        ) {



            @Override
            protected void populateViewHolder(Blogviewholder viewHolder, postitem model, int position) {

                viewHolder.settitle(model.getTitle());
                viewHolder.setdescription(model.getDescription());
                viewHolder.btncmt.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        Toast.makeText(Blog.this, "Comments", Toast.LENGTH_SHORT).show();
                        Intent intent=new Intent(Blog.this,androidview.class);
                        startActivity(intent);
                    }
                });
















            }
        };
        mbloglist.setAdapter(firebaseRecyclerAdapter);
    }

































    public static class Blogviewholder extends RecyclerView.ViewHolder{

        View mview;Button btncmt;
        public View btncmts;

        public Blogviewholder(View itemView) {
            super(itemView);
            mview=itemView;
btncmt=(Button)mview.findViewById(R.id.butlike);
        }


        public void settitle(String title){
            TextView posttitle=(TextView) mview.findViewById(R.id.titleposted);
            posttitle.setText(title);


        }

        public void setdescription(String description){
            TextView postdescription=(TextView) mview.findViewById(R.id.descposted);
            postdescription.setText(description);


        }



    }}

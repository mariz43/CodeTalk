package com.example.user.coding.java;

/**
 * Created by USER on 2/28/2018.
 */

public class postitem {   String description;
    String title;
    String image;


    public postitem(){

    }


    public postitem(String description, String title, String image) {
        this.description = description;
        this.title = title;
        this.image = image;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }


}



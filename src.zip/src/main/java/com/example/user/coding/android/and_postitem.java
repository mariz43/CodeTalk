package com.example.user.coding.android;

/**
 * Created by USER on 3/8/2018.
 */

public class and_postitem { String description;
    String title;
    String image;

    public  and_postitem(){

    }


    public and_postitem(String description, String title) {
        this.description = description;
        this.title = title;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }
}

package com.example.user.coding.html;

import android.support.v7.app.AppCompatActivity;

/**
 * Created by USER on 12/12/2017.
 */

public class htmlview  extends AppCompatActivity {
}

package com.example.user.coding.loging_system;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

import com.example.user.coding.R;


public class profile extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);
    }
}

package com.example.user.coding.android;

import android.app.ProgressDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;


import com.example.user.coding.R;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

public class Add_andblog extends AppCompatActivity {
    private FirebaseAuth firebaseAut;
    private FirebaseAuth.AuthStateListener authStateListener;
    private DatabaseReference mdatabbase;
    private ImageButton mSelectImage;
    private EditText mPosttitle;
    private EditText mPostdesc;
    private Uri mimageUri=null;
    private Button mmSubmitBtn;
    private StorageReference mstorage;
    private ProgressDialog mmprogress;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_andblog);



        firebaseAut=FirebaseAuth.getInstance();
        mdatabbase= FirebaseDatabase.getInstance().getReference().child("Androidall").child("Blog");
        mstorage= FirebaseStorage.getInstance().getReference();





        mPosttitle = (EditText) findViewById(R.id.andposttitle);
        mPostdesc = (EditText) findViewById(R.id.andpostdescription);
        mmSubmitBtn = (Button) findViewById(R.id.andssubmitpost);
        mmprogress=new ProgressDialog(this);


        mmSubmitBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sstartsposting();

            }


        });

    }

    private void sstartsposting() {

        final String titlevalue=mPosttitle.getText().toString().trim();
        final String descvalue=mPostdesc.getText().toString().trim();

        if (!TextUtils.isEmpty(titlevalue) && !TextUtils.isEmpty(descvalue)){
            mmprogress.show();


            DatabaseReference newpost=mdatabbase.push();
            newpost.child("title").setValue(titlevalue);
            newpost.child("description").setValue(descvalue);
            newpost.child("uid").setValue(firebaseAut.getCurrentUser().getUid());


            mmprogress.dismiss();
           startActivity(new Intent(Add_andblog.this,AndBlog.class));
    }




}
}
